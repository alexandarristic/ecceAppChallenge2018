// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DashboardTheme/widgets/Header/nls/strings":{_widgetLabel:"\u0110\u1ea7u m\u1ee5c",signin:"\u0110\u0103ng nh\u1eadp",signout:"\u0110\u0103ng xu\u1ea5t",about:"V\u1ec1",signInTo:"\u0110\u0103ng nh\u1eadp v\u00e0o",cantSignOutTip:"Ch\u1ee9c n\u0103ng n\u00e0y kh\u00f4ng kh\u1ea3 d\u1ee5ng trong ch\u1ebf \u0111\u1ed9 xem tr\u01b0\u1edbc.",_localized:{}}});