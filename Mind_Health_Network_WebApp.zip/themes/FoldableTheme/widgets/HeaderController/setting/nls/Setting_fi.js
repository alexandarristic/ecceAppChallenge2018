// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Nimi",openAll:"Avaa kaikki yhdess\u00e4 paneelissa",dropDown:"N\u00e4yt\u00e4 avattavassa valikossa",noGroup:"Pienoisohjelmaryhm\u00e4\u00e4 ei ole asetettu.",groupSetLabel:"Aseta pienoisohjelmaryhmien ominaisuudet",_localized:{}}});