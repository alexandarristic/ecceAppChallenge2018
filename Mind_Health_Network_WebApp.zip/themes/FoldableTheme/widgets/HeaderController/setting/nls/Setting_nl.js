// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Naam",openAll:"Alles openen in \u00e9\u00e9n deelvenster",dropDown:"Weergeven in vervolgkeuzemenu",noGroup:"Er is geen groep met widgets ingesteld.",groupSetLabel:"Eigenschappen voor groepen van widgets instellen",_localized:{}}});