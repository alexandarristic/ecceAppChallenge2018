// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"\u540d\u524d",openAll:"\u3059\u3079\u3066\u3092 1 \u3064\u306e\u30d1\u30cd\u30eb\u3067\u958b\u304f",dropDown:"\u30c9\u30ed\u30c3\u30d7\u30c0\u30a6\u30f3 \u30e1\u30cb\u30e5\u30fc\u306b\u8868\u793a",noGroup:"\u30a6\u30a3\u30b8\u30a7\u30c3\u30c8 \u30b0\u30eb\u30fc\u30d7 \u30bb\u30c3\u30c8\u304c\u3042\u308a\u307e\u305b\u3093\u3002",groupSetLabel:"\u30a6\u30a3\u30b8\u30a7\u30c3\u30c8 \u30b0\u30eb\u30fc\u30d7 \u30d7\u30ed\u30d1\u30c6\u30a3\u306e\u8a2d\u5b9a",
_localized:{}}});